// ===============================================================================
// DATA
// ===============================================================================

var frondArray = [
    {
        "name":"I like succulents",
        "photo":"https://i.imgur.com/j8OrbWh.jpg",
        "scores":[
            5,
            1,
            5,
            1,
            1,
            1,
            5,
            5,
            1,
            5
          ]
      }      
  ];
  
  // Note how we export the array. This makes it accessible to other files using require.
  module.exports = frondArray;
  